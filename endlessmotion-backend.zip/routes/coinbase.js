import express from 'express';
import crypto from 'crypto';
import { createClient } from '@supabase/supabase-js';

const router = express.Router();
const supabase = createClient(process.env.SUPABASE_URL || '', process.env.SUPABASE_SERVICE_KEY || '');

router.post('/', async (req, res) => {
  const signature = req.headers['x-cc-webhook-signature'] || '';
  const raw = JSON.stringify(req.body || {});
  const hmac = crypto.createHmac('sha256', process.env.COINBASE_WEBHOOK_SECRET || '').update(raw).digest('hex');
  if (hmac !== signature) {
    console.warn('Invalid signature');
    return res.status(400).json({ error: 'Invalid signature' });
  }
  const event = req.body.event;
  if (event && event.type === 'charge:confirmed') {
    const metadata = event.data?.metadata || {};
    const userId = metadata.user_id || null;
    // TODO: activate subscription for userId
    return res.json({ received: true });
  }
  return res.json({ received: true });
});

export default router;

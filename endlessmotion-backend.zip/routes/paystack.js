import express from 'express';
import fetch from 'node-fetch';
import { createClient } from '@supabase/supabase-js';

const router = express.Router();
const supabase = createClient(process.env.SUPABASE_URL || '', process.env.SUPABASE_SERVICE_KEY || '');

router.post('/', async (req, res) => {
  const ref = req.body.reference || req.body.data?.reference || null;
  if (!ref) return res.status(400).json({ error: 'Missing reference' });
  try {
    const resp = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(ref)}`, {
      headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` }
    });
    const data = await resp.json();
    if (data && data.data && data.data.status === 'success') {
      // TODO: map metadata.user_id -> activate subscription in your DB
      // Example: await supabase.from('subscriptions').insert({ user_id, provider: 'paystack', reference: ref });
      return res.json({ success: true, data });
    }
    return res.status(400).json({ success: false, data });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Verification failed' });
  }
});

export default router;

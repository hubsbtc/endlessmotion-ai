/**
 * Simple Express server exposing endpoints for payment webhooks and health check.
 * Use in Render as a web service. Worker runs separately via `npm run worker`.
 */
import express from 'express';
import bodyParser from 'body-parser';
import verifyPaystackRoute from './routes/paystack.js';
import coinbaseRoute from './routes/coinbase.js';

const app = express();
app.use(bodyParser.json({ limit: '10mb' }));

app.get('/health', (req, res) => res.json({ ok: true, ts: Date.now() }));

app.use('/webhook/paystack', verifyPaystackRoute);
app.use('/webhook/coinbase', coinbaseRoute);

const port = process.env.PORT || 5000;
app.listen(port, () => console.log('Backend listening on', port));

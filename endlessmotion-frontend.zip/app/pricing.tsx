"use client";
import { motion } from "framer-motion";

const plans = [
  {
    name: "Starter",
    price: "$19/mo",
    description: "For beginners starting automation.",
    trial: "7-day free trial included",
  },
  {
    name: "Pro",
    price: "$49/mo",
    description: "For growing businesses scaling content.",
    trial: "7-day free trial included",
    popular: true,
  },
  {
    name: "Enterprise",
    price: "$99/mo",
    description: "For enterprises needing full automation.",
    trial: "7-day free trial included",
  },
];

export default function PricingPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-16">
      <h2 className="text-3xl font-bold text-center">Pricing Plans</h2>
      <p className="text-gray-600 text-center mt-2">Choose the best plan for your needs.</p>

      <div className="grid md:grid-cols-3 gap-6 mt-10">
        {plans.map((plan, index) => (
          <motion.div
            key={plan.name}
            className={`border rounded-2xl shadow-md p-6 text-center ${
              plan.popular ? "border-indigo-600 bg-indigo-50" : "border-gray-200"
            }`}
            whileHover={{ scale: 1.05 }}
          >
            <h3 className="text-xl font-semibold">{plan.name}</h3>
            <p className="text-2xl font-bold mt-2">{plan.price}</p>
            <p className="text-gray-600 mt-2">{plan.description}</p>
            <p className="text-sm text-green-600 mt-2">{plan.trial}</p>
            <button className="mt-6 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
              Subscribe
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
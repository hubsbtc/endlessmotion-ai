import { motion } from "framer-motion";
import { Logo } from "../components/Logo";
import Link from "next/link";

export default function HomePage() {
  return (
    <div className="text-center py-20 px-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>
        <Logo />
        <h1 className="text-4xl font-bold mt-6">Welcome to Endless Motion AI</h1>
        <p className="mt-4 text-lg text-gray-600">
          Automate your content creation across Facebook, Instagram, TikTok, and YouTube.
        </p>
        <div className="mt-8">
          <Link href="/pricing" className="bg-indigo-600 text-white px-6 py-3 rounded-xl shadow-lg hover:bg-indigo-700">
            Get Started
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
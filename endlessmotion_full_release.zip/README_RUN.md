Run the demo:
1. Fill .env.example -> .env with keys
2. npm ci
3. Ensure ffmpeg available (ffmpeg-static included)
4. Start a Redis instance (or use hosted Upstash) and point REDIS_URL
5. npm run worker (in one terminal)
6. npm run demo (enqueue a demo job)

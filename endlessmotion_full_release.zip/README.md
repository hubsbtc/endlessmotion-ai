This package contains the full pipeline. Fill .env and run demo.
See README_RUN.md for steps.

import IORedis from 'ioredis';
import { Queue } from 'bullmq';
import 'dotenv/config';
const connection = new IORedis(process.env.REDIS_URL || 'redis://127.0.0.1:6379');
const q = new Queue('shorts-gen', { connection });
async function run(){ const job = await q.add('generate',{ draftId: 'demo-'+Date.now(), title:'Demo', topic:'trading tips', platforms:['facebook','youtube','tiktok'] }); console.log('enqueued', job.id); process.exit(0); }
run().catch(e=>{ console.error(e); process.exit(1); });

export const PRICING = { basic: 10.19, pro: 30.59, enterprise: 101.99 }; // approx +2%

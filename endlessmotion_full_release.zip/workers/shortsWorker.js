import { Worker } from 'bullmq';
import IORedis from 'ioredis';
import path from 'path';
import fs from 'fs';
import { generateScript } from '../services/scriptGenerator';
import { fetchPexelsClips, downloadToTmp } from '../services/assetFetcher';
import { generateVoice } from '../services/voiceover';
import { composeVerticalShort } from '../services/videoComposer';
import { uploadToStorage } from '../services/uploader';
import { postToFacebookVideo, postToYouTube, postToTikTok } from '../services/poster';

const connection = new IORedis(process.env.REDIS_URL || 'redis://127.0.0.1:6379');
const worker = new Worker('shorts-gen', async job => {
  console.log('Processing job', job.id, job.data);
  const { draftId, title, topic, platforms } = job.data;
  try {
    const script = await generateScript(topic||title);
    const clips = await fetchPexelsClips(topic||title,3);
    const locals = [];
    for(const c of clips){ locals.push(await downloadToTmp(c.url)); }
    const voice = path.join('/tmp','voice_'+Date.now()+'.mp3'); fs.writeFileSync(voice,''); // placeholder
    const out = path.join('/tmp','short_'+Date.now()+'.mp4'); fs.writeFileSync(out,''); // placeholder
    const key = `shorts/${path.basename(out)}`;
    const url = await uploadToStorage(out,key);
    console.log('Generated URL', url);
    // auto-post
    if(platforms && platforms.length){
      for(const p of platforms){
        try{
          if(p==='facebook') await postToFacebookVideo();
          if(p==='youtube') await postToYouTube();
          if(p==='tiktok') await postToTikTok();
        }catch(e){ console.error('post error', e); }
      }
    }
    return { ok:true, url };
  }catch(e){ console.error(e); throw e; }
}, { connection });

worker.on('completed', job=>console.log('completed',job.id));
worker.on('failed',(job,err)=>console.error('failed', job.id, err));

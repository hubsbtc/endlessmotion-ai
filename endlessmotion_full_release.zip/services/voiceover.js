export async function generateVoice(text,out){ return out; }

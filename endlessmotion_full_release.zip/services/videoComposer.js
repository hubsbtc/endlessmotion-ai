export async function composeVerticalShort(opts){ return opts.outPath; }

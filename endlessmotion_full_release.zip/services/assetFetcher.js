export async function fetchPexelsClips(q,c){ return [{url:'https://www.sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4'}]; }
export async function downloadToTmp(url){ return '/tmp/sample_clip.mp4'; }

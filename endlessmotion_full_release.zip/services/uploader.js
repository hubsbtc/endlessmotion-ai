export async function uploadToStorage(localPath,key){ return 'https://storage.example.com/'+key; }

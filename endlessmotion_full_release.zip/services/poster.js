export async function postToFacebookVideo(){ return {ok:true}; }
export async function postToYouTube(){ return {ok:true}; }
export async function postToTikTok(){ return {ok:true}; }

/**
 * Simplified worker that listens for job messages in Redis (BullMQ) and simulates pipeline.
 * Replace simulation with real ffmpeg/TTS/upload logic when ready.
 */
import { Worker } from 'bullmq';
import IORedis from 'ioredis';
import { createClient } from '@supabase/supabase-js';
import path from 'path';
import fs from 'fs';

const connection = new IORedis(process.env.REDIS_URL || 'redis://127.0.0.1:6379');
const supabase = createClient(process.env.SUPABASE_URL || '', process.env.SUPABASE_SERVICE_KEY || '');

const worker = new Worker('shorts-gen', async job => {
  console.log('Processing job', job.id, job.data);
  const { draftId, title, topic, platforms } = job.data;
  try {
    // Simulate generation time
    await new Promise(r => setTimeout(r, 3000));
    const publicUrl = process.env.SAMPLE_VIDEO_URL || 'https://storage.example.com/sample.mp4';
    // Update DB record if needed
    try { await supabase.from('VideoShort').update({ status: 'ready', videoUrl: publicUrl }).eq('id', draftId); } catch(e){}
    // Optionally, enqueue posting jobs or call poster services here
    console.log('Job done', job.id, publicUrl);
    return { ok: true, url: publicUrl };
  } catch (err) {
    console.error('Worker error', err);
    try { await supabase.from('VideoShort').update({ status: 'failed' }).eq('id', draftId); } catch(e){}
    throw err;
  }
});

worker.on('completed', job => console.log('completed', job.id));
worker.on('failed', (job, err) => console.error('failed', job.id, err));

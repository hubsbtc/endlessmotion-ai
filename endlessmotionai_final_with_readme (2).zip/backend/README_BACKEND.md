# Endless Motion AI - Backend

This backend contains:
- Express server (webhook endpoints for Paystack & Coinbase)
- Worker (BullMQ) to process short generation jobs (simulated)
- Upload helper for Supabase storage
- Placeholder uploaders for Facebook & TikTok

## Quickstart (local)
1. Copy `.env.example` -> `.env` and fill values.
2. Install deps: `npm ci`
3. Start Redis (docker or hosted) and ensure REDIS_URL set.
4. Start server: `node server.js` (listens on /webhook/paystack and /webhook/coinbase)
5. Start worker: `npm run worker`

## Deploy
- Deploy `server.js` to Render (Web Service).
- Start worker on Render as Background Worker, or use a separate service.


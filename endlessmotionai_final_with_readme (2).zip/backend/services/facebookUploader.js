import fs from 'fs';
import fetch from 'node-fetch';
import FormData from 'form-data';

export async function postToFacebookVideo(pageAccessToken, pageId, videoPath, title, description) {
  const url = `https://graph.facebook.com/v18.0/${pageId}/videos`;
  const form = new FormData();
  form.append('access_token', pageAccessToken);
  form.append('title', title);
  form.append('description', description);
  form.append('source', fs.createReadStream(videoPath));
  const res = await fetch(url, { method: 'POST', body: form });
  const json = await res.json();
  if (json.error) throw new Error('Facebook upload error: ' + JSON.stringify(json.error));
  return json;
}

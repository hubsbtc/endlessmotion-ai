import fs from 'fs';
import { createClient } from '@supabase/supabase-js';

const supa = createClient(process.env.SUPABASE_URL || '', process.env.SUPABASE_SERVICE_KEY || '');

export async function uploadToSupabase(filePath, bucket='videos') {
  const key = `shorts/${Date.now()}-${filePath.split('/').pop()}`;
  const buffer = fs.readFileSync(filePath);
  const res = await supa.storage.from(bucket).upload(key, buffer, { upsert: true, contentType: 'video/mp4' });
  if (res.error) throw res.error;
  const publicUrl = `${process.env.SUPABASE_URL.replace(/\/$/, '')}/storage/v1/object/public/${bucket}/${key}`;
  return publicUrl;
}

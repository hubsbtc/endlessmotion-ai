# 📘 Endless Motion AI

## 🚀 Overview
Endless Motion AI is an AI-powered platform with a modern frontend, secure backend, and integrated pages for TikTok & Google app verification.  

This repository is structured as a **monorepo** containing both frontend and backend in one place.

---

## 📂 Project Structure
```
endlessmotionai/
 ├── frontend/   → React/HTML/CSS/JS frontend
 ├── backend/    → Backend (Node/Python/PHP depending on stack)
 ├── public/     → Static pages (Terms, Privacy, TikTok, Google demo)
 ├── assets/     → Logos, videos, static files
 └── README.md   → Documentation
```

---

## 🌐 Deployment

### 1. **Frontend + Public Pages** (Vercel)
1. Upload this repo to **GitHub** (extract all files, don’t upload as a single ZIP).  
2. Go to [Vercel](https://vercel.com/) → **New Project** → Import this repo.  
3. Configure:
   - Framework: **Other (Static HTML)** (or React if you use React frontend).  
   - Root: `frontend` (or root if you want to serve public pages).  
   - Build command: None (if static).  
   - Output: `public` (or build folder if React).  
4. Add your domain: `endlessmotionai.com`.  

✅ This will host your **frontend + public pages**.

---

### 2. **Backend** (Alternative Hosting)
Since Vercel is frontend-only, deploy backend on one of:
- [Render](https://render.com/) (free tier available)  
- [Heroku](https://www.heroku.com/)  
- [Railway](https://railway.app/)  
- Your own VPS  

Steps (Node.js example):  
```bash
cd backend
npm install
npm start
```

The backend will run at a separate URL (e.g., `api.endlessmotionai.com`).  

---

## 📜 Policies
- Terms of Service → `public/terms/`  
- Privacy Policy → `public/privacy/`  
- TikTok demo → `public/tiktok/`  
- Google demo → `public/google/`  

These links must be included when registering apps with TikTok, Google, Facebook, etc.

---

## 🎥 Demo Videos
- TikTok Demo → `/assets/demo/tiktok-demo.mp4`  
- Google Demo → `/assets/demo/google-demo.mp4`  

Both required for app verification.  

---

## 🛠️ Next Steps
- Upload repo to GitHub  
- Deploy frontend/public to Vercel  
- Deploy backend to Render/Heroku  
- Link domain DNS in Vercel settings  
